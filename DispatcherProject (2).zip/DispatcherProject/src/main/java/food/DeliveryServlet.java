package food;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeliveryServlet
 */
public class DeliveryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeliveryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		System.out.println("<h3>Start => DeliveryServlet: doGet() called....</h3>");
		pw.println("<h3>Start => DeliveryServlet: doGet() called....</h3>");
		
		FoodItem food = (FoodItem) request.getAttribute("myfood");
		if(food.isFoodPrepared) {
			food.setFoodServed(true);
		}
		RequestDispatcher rd = request.getRequestDispatcher("/billing");
		request.setAttribute("myfood", food); 
		rd.include(request, response); //send the control to the kitchen servlet
		pw.println("<h3>Finished => DeliveryServlet: doGet() called....</h3>");
		System.out.println("<h3>Finished => DeliveryServlet: doGet() called....</h3>");
	}

}
