package food;

public class FoodItem {
	
	String foodName; //filled up by PlaceOrderServlet
	int foodQty;	//filled up by PlaceOrderServlet
	
	float price;	//implicit
	
	float billAmount; // price * foodQty
	
	boolean isOrderPlaced; // filled up by PlaceOrderServlet
	boolean isFoodPrepared;  // filled up by KitchenServlet
	boolean isFoodServed; // // filled up by DeliveryServlet
	boolean isFoodBilled; // // filled up by BillerServlet
	
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
		if(foodName.equalsIgnoreCase("Wada")) {
			this.price=60;
		}
		else if(foodName.equalsIgnoreCase("Idli")) {
			this.price=50;
		}
		else if(foodName.equalsIgnoreCase("Dosa")) {
			this.price=80;
		}
	}
	public int getFoodQty() {
		return foodQty;
	}
	public void setFoodQty(int foodQty) {
		this.foodQty = foodQty;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}
	public boolean isOrderPlaced() {
		return isOrderPlaced;
	}
	public void setOrderPlaced(boolean isOrderPlaced) {
		this.isOrderPlaced = isOrderPlaced;
	}
	public boolean isFoodPrepared() {
		return isFoodPrepared;
	}
	public void setFoodPrepared(boolean isFoodPrepared) {
		this.isFoodPrepared = isFoodPrepared;
	}
	public boolean isFoodServed() {
		return isFoodServed;
	}
	public void setFoodServed(boolean isFoodServed) {
		this.isFoodServed = isFoodServed;
	}
	public boolean isFoodBilled() {
		return isFoodBilled;
	}
	public void setFoodBilled(boolean isFoodBilled) {
		this.isFoodBilled = isFoodBilled;
	}
	
	@Override
	public String toString() {
		return "FoodItem [foodName=" + foodName + ", foodQty=" + foodQty + ", price=" + price + ", billAmount="
				+ billAmount + ", isOrderPlaced=" + isOrderPlaced + ", isFoodPrepared=" + isFoodPrepared
				+ ", isFoodServed=" + isFoodServed + ", isFoodBilled=" + isFoodBilled + "]";
	}
	
	
}
