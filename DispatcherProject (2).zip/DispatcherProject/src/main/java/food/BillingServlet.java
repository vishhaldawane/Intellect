package food;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BillingServlet
 */
public class BillingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		System.out.println("<h4>Start => BillingServlet: doGet() called....</h4>");
		pw.println("<h4>Start => BillingServlet: doGet() called....</h4>");
		
		FoodItem food = (FoodItem) request.getAttribute("myfood");
		if(food.isFoodServed) {
			food.setFoodBilled(true);
			food.setBillAmount(food.getPrice() * food.getFoodQty());
		}
		
		pw.println("<table border=5 cellspacing=10 cellpadding=10>");
			pw.println("<tr>");
					pw.println("<td> Food Name "+food.getFoodName()+"</td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
				pw.println("<td> Food Price "+food.getPrice()+"</td>");
			pw.println("</tr>");
	
			pw.println("<tr>");
				pw.println("<td> Food Qty "+food.getFoodQty()+"</td>");
			pw.println("</tr>");

			pw.println("<tr>");
				pw.println("<td> Food Bill "+food.getBillAmount()+"</td>");
			pw.println("</tr>");

		pw.println("</table>");
		
		pw.println("<h4>Finished => BillingServlet: doGet() called....</h4>");
		System.out.println("<h4>Finished => BillingServlet: doGet() called....</h4>");
	}

}
