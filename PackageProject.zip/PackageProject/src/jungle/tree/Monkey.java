package jungle.tree;

class Monkey {
	Monkey() {
		System.out.println("Monkey ctor....");
	}
	void swing() {
		System.out.println("Monkey is swinging...");
	}
}
