package jungle.tree.nest;

class Sparrow {
	Sparrow() {
		System.out.println("Sparrow ctor.....");
	}
	void layEggs() {
		System.out.println("Sparrow laying eggs...");
	}
}
