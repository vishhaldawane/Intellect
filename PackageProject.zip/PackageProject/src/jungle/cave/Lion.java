package jungle.cave;

class Lion {
	Lion() {
		System.out.println("Lion ctor..");
	}
	void roar() {
		System.out.println("Lion is roaring...");
		Tiger t = new Tiger(); //no need of import , cause of same package
		t.jump(); //protected is accessible here, cause of same package - trusted contract 
	}
}
