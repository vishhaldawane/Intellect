package jungle.cave;

public class Tiger {
	public Tiger() {
		System.out.println("Tiger ctor..");
	}
	protected void jump() {
		System.out.println("Tiger is jumping.....");
		Lion l = new Lion();
		l.roar();
	}
}
