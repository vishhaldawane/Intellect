package jungle.river;
import jungle.cave.Tiger;
class Crocodile {
	Crocodile () {
		System.out.println("Crocodile ctor....");
	}
	void swim() {
		System.out.println("Crocodile is swimming.......");
		Tiger t = new Tiger();
		t.jump();
	}
}
