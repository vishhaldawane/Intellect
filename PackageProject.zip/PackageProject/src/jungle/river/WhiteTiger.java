package jungle.river;

import jungle.cave.Tiger;

class WhiteTiger extends Tiger {
	WhiteTiger() {
		System.out.println("WhiteTiger ctor...");
	}
	void hunt() {
		jump(); //inherited access call + via extends gateway
		
		Tiger tt = new Tiger();
		tt.jump(); //via direct reference of Tiger, not accessible
		System.out.println("WhiteTiger is hunting....");
	}
}
