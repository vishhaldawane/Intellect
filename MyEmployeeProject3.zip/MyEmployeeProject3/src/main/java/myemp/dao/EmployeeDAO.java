package myemp.dao;

import java.util.List;

public interface EmployeeDAO {
	int createEmployee(Employee ref); //C
	Employee findEmployee(int empno);  //R
	List<Employee> findAllEmployees(); //R
	int updateEmployee(Employee ref); //U 
	int deleteEmployee(int empno);  //  D
}
