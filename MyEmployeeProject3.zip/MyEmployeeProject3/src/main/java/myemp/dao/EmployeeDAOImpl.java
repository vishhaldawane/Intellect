package myemp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO {

	Connection conn; // hasA
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	
	public void releaseDBResources() {
		try {
			try {
				rs.close();			
				st.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("DB resources closed...");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public EmployeeDAOImpl()
	{
		System.out.println("EmployeeDAOImpl: EmployeeDAOImpl() ctor...");
			try {
				//1 load the driver...
				System.out.println("Trying to load the driver ...");
				//below line will find the driver for eclipse to compile
				//but how about tomcat at runtime???
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
				//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
				System.out.println("Driver loaded...");
			//2
				System.out.println("Trying to connect to the database...");
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
				//Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
				System.out.println("Connected to the database..."+conn);
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	@Override
	public int createEmployee(Employee ref) {
		System.out.println("EmployeeDAOImpl: create(Employee) ...");
		// TODO Auto-generated method stub
		int empno = ref.getEmployeeNumber();
		String ename = ref.getEmployeeName();
		String job = ref.getEmployeeJob();
		int mgr = ref.getEmployeeManager();
		
		java.sql.Date joining = ref.getEmployeeJoining();
			/*java.util.Date dojInUtil = new SimpleDateFormat("yyyy-MM-dd").parse(dateInStr);
			System.out.println("DOJ "+dojInUtil);
		java.sql.Date joining = new java.sql.Date(dojInUtil.getTime());*/
			System.out.println("JOINING : "+joining);
		float sal = ref.getEmployeeSalary();
		float comm = ref.getEmployeeComm();
		int deptno = ref.getEmployeeDepartmentNumber();
		int row =0;
		try {
			pst = conn.prepareStatement("insert into emp values (?,?,?,?,?,?,?,?)");
			pst.setInt(1, empno);
			pst.setString(2, ename);
			pst.setString(3, job);
			pst.setInt(4, mgr);
			pst.setDate(5, joining);
			pst.setFloat(6, sal);
			pst.setFloat(7, comm);
			pst.setInt(8, deptno);
			row = pst.executeUpdate();
			if(row!=0) {
				System.out.println("Row Created :"+row);
			}
			else {
				System.out.println("No Rows Created:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	@Override
	public Employee findEmployee(int eno) {
		
		System.out.println("EmployeeDAOImpl: findEmployee(int) ...");
			Employee empObj= null;
			
			try {
				System.out.println("What is empno   "+eno);
				st = conn.createStatement();
				rs = st.executeQuery("select * from emp WHERE empno="+eno);
				//4 process it
				if(rs.next()) 
				{ //if the record is found
					int empno 	 = rs.getInt(1);
					String ename = rs.getString(2);
					String job   =  rs.getString(3);
					int mgr      =  rs.getInt(4);
					java.sql.Date date = rs.getDate(5);
					float salary = rs.getFloat(6);
					float comm   = rs.getFloat(7);
					int deptno   = rs.getInt(8);
					
					empObj = new Employee();
					empObj.setEmployeeNumber(empno);
					empObj.setEmployeeName(ename);
					empObj.setEmployeeJob(job);
					empObj.setEmployeeManager(mgr);
					empObj.setEmployeeJoining(date);
					empObj.setEmployeeSalary(salary);
					empObj.setEmployeeComm(comm);
					empObj.setEmployeeDepartmentNumber(deptno);
					
					System.out.println("EMPNO  : "+empno);
					System.out.println("NAME   : "+ename);
					System.out.println("JOB    : "+job);
					System.out.println("MGR    : "+mgr);
					System.out.println("DOJ    : "+date);
					System.out.println("SAL    : "+salary);
					System.out.println("COMM   : "+comm);
					System.out.println("DEPTNO : "+deptno);
					System.out.println("-----------------------------");	
				
				}
				else {
					return null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return empObj;
	}

	@Override
	public List<Employee> findAllEmployees() {
		System.out.println("EmployeeDAOImpl: findAllEmployees() ...");
		List<Employee> empList = new ArrayList<Employee>();
		
		Employee empObj= null;
		
		try {
			st = conn.createStatement();
			rs = st.executeQuery("select * from emp");
			//4 process it
			while (rs.next()) 
			{ //if the record is found
				int empno 	 = rs.getInt(1);
				String ename = rs.getString(2);
				String job   =  rs.getString(3);
				int mgr      =  rs.getInt(4);
				java.sql.Date date = rs.getDate(5);
				float salary = rs.getFloat(6);
				float comm   = rs.getFloat(7);
				int deptno   = rs.getInt(8);
				
				empObj = new Employee(); //make a new employee during each iteration
				
				empObj.setEmployeeNumber(empno);
				empObj.setEmployeeName(ename);
				empObj.setEmployeeJob(job);
				empObj.setEmployeeManager(mgr);
				empObj.setEmployeeJoining(date);
				empObj.setEmployeeSalary(salary);
				empObj.setEmployeeComm(comm);
				empObj.setEmployeeDepartmentNumber(deptno);
				
				System.out.println("EMPNO  : "+empno);
				System.out.println("NAME   : "+ename);
				System.out.println("JOB    : "+job);
				System.out.println("MGR    : "+mgr);
				System.out.println("DOJ    : "+date);
				System.out.println("SAL    : "+salary);
				System.out.println("COMM   : "+comm);
				System.out.println("DEPTNO : "+deptno);
				System.out.println("-----------------------------");	
				empList.add(empObj); // add this new emp object in the arraylist
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public int updateEmployee(Employee ref) {
		System.out.println("EmployeeDAOImpl: updateEmployees(Employee) ...");
		int empNoToModify = ref.getEmployeeNumber();
		String empJobModify = ref.getEmployeeJob();
		float empSalaryModify = ref.getEmployeeSalary();
		int row=0;
		try {
			pst = conn.prepareStatement("update emp set job=?, sal=? where empno=?");
			pst.setString(1, empJobModify);
			pst.setFloat(2, empSalaryModify);
			pst.setInt(3, empNoToModify);
			row = pst.executeUpdate();
			if(row!=0) {
				System.out.println("Row Updated :"+row);
			}
			else {
				System.out.println("No Rows Updated:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

	@Override
	public int deleteEmployee(int empno) {
		System.out.println("EmployeeDAOImpl: deleteEmployees(int) ...");
		int row = 0;
		try {
			pst = conn.prepareStatement("delete from emp where empno=?");
			pst.setInt(1, empno);
			row = pst.executeUpdate();
			if(row!=0) {
				System.out.println("Row delelted :"+row);
			}
			else {
				System.out.println("No Rows delelted :");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}

}
