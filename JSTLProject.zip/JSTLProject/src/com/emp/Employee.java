package com.emp; //must have package 1
//we call it as POJO - it is also known as "Java Bean"
//2 must be public declaration
public class Employee {
	//3 must have private data
	private int employeeNumber;
	private String employeeName;
	private String employeeJob;
	
	//4 must have no-arg constructor - default ctor

	//5 must have setters/getters
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeJob() {
		return employeeJob;
	}
	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}
	
	
}
