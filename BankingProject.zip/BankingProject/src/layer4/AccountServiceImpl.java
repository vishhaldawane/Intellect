package layer4; //ACTUAL BUSINESS OF THE BANK - THE SERVICES 

import layer2.Account;
import layer3.AccountRepositoryImpl;

public class AccountServiceImpl implements AccountService {

	AccountRepositoryImpl accRepo = new AccountRepositoryImpl();
	
	@Override
	public Account findAccountService(int acno) {
		System.out.println("AccountServiceImpl...searching for account...."+acno);
		Account accTemp = accRepo.selectAccount(acno);
		return accTemp;
	}

	@Override
	public void createAccountService(Account acc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void modifyAccountService(Account acc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeAccountService(int acno) {
		// TODO Auto-generated method stub

	}

}
