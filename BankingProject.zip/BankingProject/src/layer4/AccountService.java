package layer4;

import layer2.Account;

public interface AccountService {
	Account findAccountService(int acno);
	void createAccountService(Account acc); //ctrl+shift+M
	void modifyAccountService(Account acc);
	void removeAccountService(int acno);
	
}
