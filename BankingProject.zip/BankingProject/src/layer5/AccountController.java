package layer5; // THIS IS YOUR MIDDLE LEVEL SERVER TO TAKING INPUT FROM HTML / ANGULAR / REACT PAGES

import layer2.Account;
import layer4.AccountServiceImpl;

public class AccountController {

	AccountServiceImpl accService = new AccountServiceImpl();
	
		public Account findAccount(int acno) {
			System.out.println("Controller is searching for acno : "+acno);
			Account acc = accService.findAccountService(acno);
			return acc;
		}
}
