package layer6; //PRESENTATION LAYER OF HTML CSS JAVA SCRIPT

import java.util.Scanner;

import layer2.Account;
import layer5.AccountController;

public class MyHtmlPage {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter acno : ");
		int acno = scan.nextInt();
		System.out.println("HTML searching for acno "+acno);
		AccountController accController = new AccountController();
		Account acc = accController.findAccount(acno);
		if(acc!=null) {
			System.out.println("== Account Details ==");
			System.out.println("Account Number  : "+acc.getAccountNumber());
			System.out.println("Account Name    : "+acc.getAccountHolderName());
			System.out.println("Account Balance : "+acc.getAccountBalance());
		}
		else {
			System.out.println("Account not found "+acno);
		}
	}
}
