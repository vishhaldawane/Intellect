package layer3;
import layer2.Account;

public interface AccountRepository {
	Account selectAccount(int acno);
	void insertAccount(Account aRef);
	void updateAccount(Account aRef);
	void deleteAccount(int acno);
}
