package layer3; // THE KITCHEN - OF THE BANK - 

import layer2.Account;

public class AccountRepositoryImpl implements AccountRepository {

	Account allAccounts[] = new Account[10]; 
	
	public AccountRepositoryImpl () { //below is simulation of layer1
		allAccounts[0]= new Account(101,"Jack",50000);
		allAccounts[1]= new Account(102,"Jane",60000);
		allAccounts[2]= new Account(103,"Peter",70000);
		for(int i=3;i<10;i++) {
			allAccounts[i] = new Account(); //blank account 
		}
	}
	
	@Override
	public Account selectAccount(int acno) {
		System.out.println("AccountRepositoryImpl...searching for account...."+acno);
		Account accObj = null;
		
		boolean found=false;
		int i=0;
		for(;i<allAccounts.length;i++) {
			if(allAccounts[i].getAccountNumber() == acno) {
				accObj = allAccounts[i];
				found=true;
				break;
			}
		}
		if(found==true)
			return accObj;
		else
			return null;
	}

	@Override
	public void insertAccount(Account aRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccount(Account aRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAccount(int acno) {
		// TODO Auto-generated method stub

	}

}
