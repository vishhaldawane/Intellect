package carrom;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PlayerOneServlet
 */
public class PlayerThreeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlayerThreeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);	
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int  score=300;
		
		ServletConfig cfg = getServletConfig();
		System.out.println("cfg "+cfg);
		ServletContext ctx = cfg.getServletContext(); //handle to tomcat
		
		PrintWriter pw = response.getWriter();
		pw.println("<h2>Page    : "+score+"</h2>");
		pw.println("<h2>Config  : "+cfg.getServletName()+"</h2>");
		pw.println("<h2>User    : "+cfg.getInitParameter("username")+"</h2>");
		
		pw.println("<h2>Context : "+ctx.getServerInfo()+"</h2>");
		pw.println("<h2>Context : "+ctx.getMajorVersion()+"</h2>");
		pw.println("<h2>Context : "+ctx.getMinorVersion()+"</h2>");
		
		String ts3 = ctx.getInitParameter("TotalScore");
		pw.println("<h2>Context Score : "+ts3+"</h2>");
		
		pw.println("<h2>Context Driver : "+ctx.getInitParameter("DriverName")+"</h2>");
		
		
		pw.println("<a href='http://localhost:8085/ContextConfigProject/'> click Back </a> <br>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
