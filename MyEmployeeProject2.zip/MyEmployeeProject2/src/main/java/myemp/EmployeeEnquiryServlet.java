package myemp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import myemp.dao.Employee;
import myemp.dao.EmployeeDAOImpl; //Ramesh at service now 


			//Rajesh - "hasA" Ramesh as  a containment

public class EmployeeEnquiryServlet extends GenericServlet {
	
	EmployeeDAOImpl empDao ; //RAMESH IS WORKING WITH RAJESH
	
    public EmployeeEnquiryServlet() {
        super();
        System.out.println("EmployeeEnquiryServlet() constructor...");
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("init()...LOAD THE DRIVER....");
		empDao = new EmployeeDAOImpl();//RAMESH IS WORKING HERE
	}

	
	public void destroy() {
				
		System.out.println("destroy()...");
		empDao.releaseDBResources();//RAMESH IS WORKING HERE
		
	}

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		try
		{
			System.out.println("\tservice()...Host : "+request.getRemoteHost()+" Port : "+request.getRemotePort());
			PrintWriter pw = response.getWriter();
			
			String whatIsClicked = request.getParameter("submit"); //read the value of the submit button
			
			if(whatIsClicked.equals("Find Employee"))
			{
				String whatIsEmpno = request.getParameter("myempno"); // read the value of the input type
				System.out.println("What is clicked "+whatIsClicked);
				System.out.println("What is empno   "+whatIsEmpno);
				
				int eno = Integer.parseInt(whatIsEmpno);
				Employee empObj = empDao.findEmployee(eno); //RAMESH IS WORKING HERE
					if(empObj!=null)
					{
							pw.println("<html>");
								pw.println("<title>Employee Enquiry Servlet</title>");
								pw.println("<body>");
								pw.println("<h1 align=center> Employee Enquiry Servlet</h1>");
							
								pw.println("</body>");
								pw.println("<table border=5 cellspacing=10 cellpadding=10>");
								pw.println("<tr>");
									pw.println("<td> EMPNO </td>");	pw.println("<td>"+empObj.getEmployeeNumber()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> EMPNAME </td>");	pw.println("<td>"+empObj.getEmployeeName()+"</td>");
								pw.println("</tr>");
						
								pw.println("<tr>");
									pw.println("<td> JOB </td>");	pw.println("<td>"+empObj.getEmployeeName()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> MANAGER </td>");	pw.println("<td>"+empObj.getEmployeeManager()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> JOINING </td>");	pw.println("<td>"+empObj.getEmployeeJoining()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> SALARY </td>");	pw.println("<td>"+empObj.getEmployeeSalary()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> COMM </td>");	pw.println("<td>"+empObj.getEmployeeComm()+"</td>");
								pw.println("</tr>");
							
								pw.println("<tr>");
									pw.println("<td> DEPTNO </td>");	pw.println("<td>"+empObj.getEmployeeDepartmentNumber()+"</td>");
								pw.println("</tr>");	
					}
					else {
						pw.println("<tr>");
							pw.println("<td> EMPNO NOT FOUND : </td>");	
							pw.println("</tr>");
					}
			}
			else if(whatIsClicked.equals("Find All Employees")) {
				
				List<Employee> empList = empDao.findAllEmployees(); //RAMESH IS WORKING WITH RAJESH
				
				pw.println("<html>");
				pw.println("<title>Employee Enquiry Servlet</title>");
				pw.println("<body>");
				pw.println("<h1 align=center> Employee Enquiry Servlet</h1>");
				pw.println("<table align=center  border=5 cellspacing=10 cellpadding=10>");
				pw.println("<th> EMPNO </th>");	
				pw.println("<th> EMPNAME </th>");
				pw.println("<th> JOB </th>");	
				pw.println("<th> MANAGER </th>");
				pw.println("<th> JOINING </th>");
				pw.println("<th> SALARY </th>");
				pw.println("<th> COMM </th>");	
				pw.println("<th> DEPTNO </th>");
				
				Iterator<Employee> empIter = empList.iterator();
				
				while(empIter.hasNext()) 
				{ //if the record is found
					Employee  x = empIter.next();
					System.out.println("EMPNO  : "+x.getEmployeeNumber());
					System.out.println("NAME   : "+x.getEmployeeName());
					System.out.println("JOB    : "+x.getEmployeeJob());
					System.out.println("MGR    : "+x.getEmployeeManager());
					System.out.println("DOJ    : "+x.getEmployeeJoining());
					System.out.println("SAL    : "+x.getEmployeeSalary());
					System.out.println("COMM   : "+x.getEmployeeComm());
					System.out.println("DEPTNO : "+x.getEmployeeDepartmentNumber());
					System.out.println("-----------------------------");	
				
					
						pw.println("<tr>");
								pw.println("<td>"+x.getEmployeeNumber()+"</td>");
								pw.println("<td>"+x.getEmployeeName()+"</td>");
								pw.println("<td>"+x.getEmployeeJob()+"</td>");
								pw.println("<td>"+x.getEmployeeManager()+"</td>");
								pw.println("<td>"+x.getEmployeeJoining()+"</td>");
								pw.println("<td>"+x.getEmployeeSalary()+"</td>");
								pw.println("<td>"+x.getEmployeeComm()+"</td>");
								pw.println("<td>"+x.getEmployeeDepartmentNumber()+"</td>");
						pw.println("</tr>");	
				}
				
				pw.println("</table>");
				
			}
			else if(whatIsClicked.equals("Delete Employee")) {
				int empNoToDelete = Integer.parseInt(request.getParameter("myempno"));
				int row = empDao.deleteEmployee(empNoToDelete);
				if(row!=0) {
					System.out.println("Row delelted :"+row);
					pw.println("<h3>Row deleted </h3>");
				}
				else {
					System.out.println("No Rows delelted :");
					pw.println("<h3>Record Not Found </h3>");
				}
			}
			else if (whatIsClicked.equals("Modify Employee")) {

				//below 3 lines to read from html
				int empNoToModify = Integer.parseInt(request.getParameter("myempno"));
				String empJobModify = request.getParameter("newjob");
				float empSalaryModify = Float.parseFloat(request.getParameter("newsalary"));
				
				//below object to fill up teh values fetched in above 3 lines
				Employee empToModify = new Employee();
				empToModify.setEmployeeNumber(empNoToModify);
				empToModify.setEmployeeJob(empJobModify);
				empToModify.setEmployeeSalary(empSalaryModify);
				
				int row = empDao.updateEmployee(empToModify); //RAMESH IS WORKING WITH RAJESH
			
				if(row!=0) {
					System.out.println("Row Updated :"+row);
					pw.println("<h3>Row Updated </h3>");
				}
				else {
					System.out.println("No Rows Updated:");
					pw.println("<h3>Record Not Found </h3>");
				}
				
			}
			else if(whatIsClicked.equals("Create Employee")) {
				
				int row=0;
				
				int empno = Integer.parseInt(request.getParameter("myempno"));
				String ename = request.getParameter("ename");
				String job = request.getParameter("job");
				int mgr = Integer.parseInt(request.getParameter("mgr"));
				
					String dateInStr = request.getParameter("joining");
					java.util.Date dojInUtil = new SimpleDateFormat("yyyy-MM-dd").parse(dateInStr);
					System.out.println("DOJ "+dojInUtil);
				java.sql.Date joining = new java.sql.Date(dojInUtil.getTime());
					System.out.println("JOINING : "+joining);
				float sal = Float.parseFloat(request.getParameter("sal"));
				float comm = Float.parseFloat(request.getParameter("comm"));
				int deptno = Integer.parseInt(request.getParameter("deptno"));
				
				Employee empToInsert = new Employee(); // a blank object
				
				//fill up the object
				empToInsert.setEmployeeNumber(empno);
				empToInsert.setEmployeeName(ename);
				empToInsert.setEmployeeJob(job);
				empToInsert.setEmployeeManager(mgr);
				empToInsert.setEmployeeJoining(joining);
				empToInsert.setEmployeeSalary(sal);
				empToInsert.setEmployeeComm(comm);
				empToInsert.setEmployeeDepartmentNumber(deptno);
				
				row = empDao.createEmployee(empToInsert); //RAMESH IS WORKING WITH RAJESH
				
				if(row!=0) {
					System.out.println("Row Created :"+row);
					pw.println("<h3>Row Created </h3>");
				}
				else {
					System.out.println("No Rows Created:");
				}
			}
			
			pw.println("<a href='http://localhost:8085/MyEmployeeProject/'>Home</a>");
			pw.println("</body>");
			pw.println("</html>");
		} // end of try
		
		catch(Exception e) {
			System.out.println("Some problem : "+e);
		}
	}
	

}
