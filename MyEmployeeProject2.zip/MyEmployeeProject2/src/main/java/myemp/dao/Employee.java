package myemp.dao;

public class Employee { //POJO to represent your table/relation 
	private int employeeNumber;
	private String employeeName;
	private String employeeJob;
	private int employeeManager;
	private java.sql.Date employeeJoining;
	private float employeeSalary;
	private float employeeComm;
	private int employeeDepartmentNumber;
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeJob() {
		return employeeJob;
	}
	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}
	public int getEmployeeManager() {
		return employeeManager;
	}
	public void setEmployeeManager(int employeeManager) {
		this.employeeManager = employeeManager;
	}
	public java.sql.Date getEmployeeJoining() {
		return employeeJoining;
	}
	public void setEmployeeJoining(java.sql.Date employeeJoining) {
		this.employeeJoining = employeeJoining;
	}
	public float getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public float getEmployeeComm() {
		return employeeComm;
	}
	public void setEmployeeComm(float employeeComm) {
		this.employeeComm = employeeComm;
	}
	public int getEmployeeDepartmentNumber() {
		return employeeDepartmentNumber;
	}
	public void setEmployeeDepartmentNumber(int employeeDepartmentNumber) {
		this.employeeDepartmentNumber = employeeDepartmentNumber;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", employeeJob="
				+ employeeJob + ", employeeManager=" + employeeManager + ", employeeJoining=" + employeeJoining
				+ ", employeeSalary=" + employeeSalary + ", employeeComm=" + employeeComm
				+ ", employeeDepartmentNumber=" + employeeDepartmentNumber + "]";
	}
	
	
}
