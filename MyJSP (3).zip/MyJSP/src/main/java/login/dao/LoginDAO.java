package login.dao;

import register.dao.Register;

public interface LoginDAO {
	Register authenticateTheuser(Login log);
}
