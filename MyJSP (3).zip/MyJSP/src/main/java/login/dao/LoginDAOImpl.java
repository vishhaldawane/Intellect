package login.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import register.dao.Register;


public class LoginDAOImpl implements LoginDAO {

	Connection conn; // hasA
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	
	public LoginDAOImpl() {
		System.out.println("LoginDAOImpl: LoginDAOImpl() ctor...");
		try {
			//1 load the driver...
			System.out.println("Trying to load the driver ...");
			//below line will find the driver for eclipse to compile
			//but how about tomcat at runtime???
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded...");
		//2
			System.out.println("Trying to connect to the database...");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			//Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the database..."+conn);
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public Register  authenticateTheuser(Login log) {
		System.out.println("Authenticating...");
		Register theRegisteredUser = null;
		
		try {
			st = conn.createStatement();
			rs = st.executeQuery("select * from register where username="+"'"+log.getUsername()+"' and password="+"'"+log.getPassword()+"'");
			if(rs.next()) {
				theRegisteredUser = new Register();
				System.out.println("DAO : hashCode  : "+theRegisteredUser);
				theRegisteredUser.setUsername(rs.getString(1)); //Spring JPA Crud Repository
				theRegisteredUser.setPassword(rs.getString(2));
				theRegisteredUser.setFirstname(rs.getString(3));
				theRegisteredUser.setAddress(rs.getString(4));
				theRegisteredUser.setQualification(rs.getString(5));
				theRegisteredUser.setCity(rs.getString(6));
				theRegisteredUser.setPin(rs.getString(7));
				theRegisteredUser.setState(rs.getString(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Authentication complete...");
		return theRegisteredUser;
	}
	

}
