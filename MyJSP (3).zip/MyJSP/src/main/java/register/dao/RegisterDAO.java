package register.dao;

public interface RegisterDAO {
	void createUser(Register reg);
}
