package register.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class RegisterDAOImpl implements RegisterDAO {

	Connection conn; // hasA
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	
	public void releaseDBResources() {
		try {
			try {
				rs.close();			
				st.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("DB resources closed...");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public RegisterDAOImpl()
	{
		System.out.println("EmployeeDAOImpl: EmployeeDAOImpl() ctor...");
			try {
				//1 load the driver...
				System.out.println("Trying to load the driver ...");
				//below line will find the driver for eclipse to compile
				//but how about tomcat at runtime???
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
				//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
				System.out.println("Driver loaded...");
			//2
				System.out.println("Trying to connect to the database...");
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
				//Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
				System.out.println("Connected to the database..."+conn);
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	@Override
	public void  createUser(Register ref) {
		System.out.println("RegisterDAOImpl: createUser(Register) ...");
		// TODO Auto-generated method stub
		String username= ref.getUsername();
		String password= ref.getPassword();
		String firstname= ref.getFirstname();
		String address= ref.getAddress();
		String qualification= ref.getQualification();
		String city= ref.getCity();
		String pin= ref.getPin();
		String state= ref.getState();
		
				int row =0;
		try {
			pst = conn.prepareStatement("insert into register values (?,?,?,?,?,?,?,?)");
			pst.setString(1, username);
			pst.setString(2, password);
			pst.setString(3, firstname);
			pst.setString(4, address);
			pst.setString(5, qualification);
			pst.setString(6, city);
			pst.setString(7, pin);
			pst.setString(8, state);
			row = pst.executeUpdate();
			if(row!=0) {
				System.out.println("Row Created :"+row);
			}
			else {
				System.out.println("No Rows Created:");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
