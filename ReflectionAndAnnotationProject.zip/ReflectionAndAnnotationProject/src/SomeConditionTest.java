import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class SomeConditionTest {
	public static void main(String[] args) {
		
		//lets use the flight class..
		
		Flight f = new Flight(101,"Lufthansa","Mumbai","Germany");
		
		Class c = f.getClass();
		Annotation allAnno[] = c.getAnnotations();
		
		if(allAnno.length!=0) {
			for (int i = 0; i < allAnno.length; i++) {
				Annotation anno= allAnno[i];
				System.out.println("Annotation is : "+anno);
				DevelopedBy db = (DevelopedBy) anno;
				if(db.name().equalsIgnoreCase("Nikitha")) {
					System.out.println("Loading the class....");
				}
				else {
					System.out.println("Class loading failed....");
				}
			}
		}
		else {
			System.out.println("Annotation is missing...for the Flight class");
		}
		
		Method m[] = c.getMethods();
		for (int i = 0; i < m.length; i++) {
			Method method = m[i];
			System.out.println("method : "+method.getName());
			Annotation allMethAno[] = method.getAnnotations();
			for (int j = 0; j < allMethAno.length; j++) {
				Annotation annotation = allMethAno[j];
				System.out.println("Method anno : "+annotation);
			}
		}
		
	}
}
