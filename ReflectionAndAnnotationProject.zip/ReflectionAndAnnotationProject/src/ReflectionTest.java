import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Iterator;

/*Developed by Nikitha*/
@DevelopedBy(name="Rajesh") // extra information of the class
class Flight
{
	/*this is the unique field for every flight*/
	
	@ImportantKey(min=1,max=10)
	int flightNumber;
	String flightName;
	String source;
	String destination;
	
	/*each flight must have its flight number - developed by Akshay*/
	public Flight(int flightNumber) {
		super();
		this.flightNumber = flightNumber;
	}
	public Flight(int flightNumber, String flightName) {
		super();
		this.flightNumber = flightNumber;
		this.flightName = flightName;
	}
	public Flight(int flightNumber, String flightName, String source) {
		super();
		this.flightNumber = flightNumber;
		this.flightName = flightName;
		this.source = source;
	}
	public Flight(int flightNumber, String flightName, String source, String destination) {
		super();
		this.flightNumber = flightNumber;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
	}
	
	public void showFlight() {
		System.out.println("Flight [flightNumber=" + flightNumber + ", flightName=" + flightName + ", source=" + source
				+ ", destination=" + destination + "]");
	}
	
	/*this method is the imp business method - developed by Sahana*/
	@MethodDevelopedBy(name="Sahana", version=1.0)
	public void fly() {
		System.out.println("Flight is flying....");
	}
	
	/*this method is the imp business method - developed by Akash*/
	public void land() {
		System.out.println("Flight is landing....");
	}	
	
	static int myclass=100;
}
//for us it is development time, but for eclipse it is runtime
public class ReflectionTest {
	public static void main(String[] args) {
		Flight f = new Flight(101,"AirIndia","Mumbai","London");
		
		Class theClassMirror= f.getClass();
		
		Constructor allCtors [] = theClassMirror.getConstructors();
		for (int i = 0; i < allCtors .length; i++) {
			System.out.println("-- Constructor information -- ");
			Constructor ctor= allCtors [i];
			System.out.println("Constructor name : "+ctor.getName());
			System.out.println("Constructor with : "+ctor.getParameterCount()+" parameters");
			Parameter allParas[] = ctor.getParameters();
				for (int j = 0; j < allParas.length; j++) {
					Parameter para = allParas[j];
					System.out.println("Para : "+para.getType());
				}
		}
		
		Method allMethods[] = theClassMirror.getMethods();
		for (int i = 0; i < allMethods.length; i++) {
			Method method = allMethods[i];
			System.out.println("Method name : "+method.getName());
		}
		
	}
}
