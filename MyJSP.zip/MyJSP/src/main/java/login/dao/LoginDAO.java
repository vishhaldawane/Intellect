package login.dao;

public interface LoginDAO {
	Login authenticateTheuser(Login log);
}
