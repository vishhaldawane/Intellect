package login.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDAOImpl implements LoginDAO {

	Connection conn; // hasA
	Statement st;
	ResultSet rs;
	PreparedStatement pst;
	
	public LoginDAOImpl() {
		System.out.println("LoginDAOImpl: LoginDAOImpl() ctor...");
		try {
			//1 load the driver...
			System.out.println("Trying to load the driver ...");
			//below line will find the driver for eclipse to compile
			//but how about tomcat at runtime???
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded...");
		//2
			System.out.println("Trying to connect to the database...");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:OSE", "system", "manager");
			//Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA", "");
			System.out.println("Connected to the database..."+conn);
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public Login authenticateTheuser(Login log) {
		System.out.println("Authenticating...");
		Login theLogin = null;
		
		try {
			st = conn.createStatement();
			rs = st.executeQuery("select * from login where username="+"'"+log.getUsername()+"' and password="+"'"+log.getPassword()+"'");
			if(rs.next()) {
				theLogin = new Login();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Authentication complete...");
		return theLogin;
	}
	

}
