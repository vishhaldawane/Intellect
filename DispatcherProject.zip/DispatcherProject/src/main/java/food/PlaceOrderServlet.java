package food;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PlaceOrderServlet extends HttpServlet {
	
    public PlaceOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.println("<h1> PlaceOrderServlet: doGet() called....</h1>");
		String foodName = request.getParameter("foodname");
		int qty = Integer.parseInt(request.getParameter("foodqty"));
		
		FoodItem food = new FoodItem(); //blank object
		
		food.setFoodName(foodName);
		food.setFoodQty(qty);
		food.setOrderPlaced(true);
		
		RequestDispatcher rd = request.getRequestDispatcher("/kitchen");
		request.setAttribute("myfood", food); 
		rd.forward(request, response); //send the control to the kitchen servlet 
	}

}
